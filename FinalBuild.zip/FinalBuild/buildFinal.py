# Import Tkinter
from tkinter import *
import tkinter as tk
import os

# First Main Window
w1 = Tk()
w1.geometry("425x512")
w1.resizable(False, False)
w1.title("Free_Money")
# This is used to set my icon for the application
w1.iconbitmap("projFiles/logo.ico")
# Used to set up the background
bg1 = PhotoImage(file="projFiles/bgf1.png")
bg2 = PhotoImage(file="projFiles/bgf2.png")

# Setting the background for the first window
bgLab = Label(w1, image=bg1)
bgLab.place(x=0, y=0, relwidth=1, relheight=1)


# Billing Window
def winbills():
    w2 = Toplevel()
    w2.resizable(False, False)
    w2.title("Enter Bills Due")
    w2.geometry("260x260")
    bgLab2 = Label(w2, image=bg2)
    bgLab2.place(x=0, y=0, relwidth=1, relheight=1)
    Label(w2, text="Enter Your Total Bills Due Each Month").pack(pady=20, padx=20)
    billent = tk.Entry(w2)
    billent.pack()

# Going through the process of saving and checking the bill input
    def billSubmit():
        # Getting the value of the bill
        bill_entry = billent.get()
        # Trying the input to make sure it is valid
        try:
            float_inputb = float(bill_entry)
            tot_bills = (str(bill_entry))
            formatted_value_bill = "${:,.2f}".format(float(tot_bills))
            outputBill.config(text=str(formatted_value_bill))
            total_billing = bill_entry
            f = open("projFiles/bf.txt", "w")
            f.write(str(total_billing))
            f.close()
            w2.destroy()
        # Displaying error if input is invalid
        except ValueError:
            billent.delete(0, END)
            del bill_entry
            tk.Label(w2, text="Please Enter Valid Format", bg='#FF0000').pack()

# Simple func to kill the window
    def killwindowb():
        w2.destroy()

# Button to call on submit code
    tk.Button(w2, text="Submit Value", command=lambda: [billSubmit()]).pack(pady=20)
    tk.Button(w2, text="Return to Main Page", command=killwindowb).pack(pady=35)

# Income Window
def wininc():
    w3 = Toplevel()
    w3.resizable(False, False)
    w3.title("Enter Total Income")
    bgLab3 = Label(w3, image=bg2)
    bgLab3.place(x=0, y=0, relwidth=1, relheight=1)
    w3.geometry("260x260")
    Label(w3, text="Enter Your Total Monthly Income").pack(pady=20, padx=20)
    incent = tk.Entry(w3)
    incent.pack()

    # Going through the process of saving and checking the income input
    def incSubmit():
        # Getting the income value
        inc_entry = incent.get()
        # Trying the input to make sure it is valid
        try:
            float_input = float(inc_entry)
            tot_inc = (str(inc_entry))
            formatted_value_inc = "${:,.2f}".format(float(tot_inc))
            outputInc.config(text=str(formatted_value_inc))
            total_income = float_input
            f = open("projFiles/if.txt", "w")
            f.write(str(total_income))
            f.close()
            w3.destroy()
        # Displaying error if input is invalid
        except ValueError:
            incent.delete(0, END)
            del inc_entry
            tk.Label(w3, text="Please Enter Valid Format", bg='#FF0000').pack()

# Simple func to kill the window
    def killwindowi():
        w3.destroy()
    # Button to call on submit code
    tk.Button(w3, text="Submit Value", command=lambda: [incSubmit()]).pack(pady=20)
    tk.Button(w3, text="Return to Main Page", command=killwindowi).pack(pady=35)


# Calculating the total
def calFree():
    # Grabbing the totals from the files
    bf = open("projFiles/bf.txt", "r")
    totbill = bf.read()
    bf.close()
    incf = open("projFiles/if.txt", "r")
    totinc = incf.read()
    incf.close()
# Running the simple math
    free_money = (float(totinc)) - (float(totbill))

    # Deleting the files so they are not stored longer than needed
    if os.path.exists("projFiles/if.txt"):
        os.remove("projFiles/if.txt")
    if os.path.exists("projFiles/bf.txt"):
        os.remove("projFiles/bf.txt")
# Formatting and pushing results
    formatted_value_tot = "${:,.2f}".format(float(free_money))
    outputFree.config(text=str(formatted_value_tot))


# Closing program
def closeprog():
    w1.destroy()


# Set Up the Bill Button to Open the Income Menu
moneyInc = Button(w1, text="  Income  ", command=wininc, font=('Arial', 15))
moneyInc.grid(row=0, column=0, sticky=W, pady=50, padx=16)

# Output the Result of the Income Menu
outputInc = Label(w1, font=('Arial', 18))
outputInc.grid(row=0, column=1, sticky=E)

# Set Up the Bill Button to Open the Bill Menu
moneyBill = Button(w1, text="    Bills    ", command=winbills, font=('Arial', 15))
moneyBill.grid(row=1, column=0, sticky=W, padx=16)

# Output the Result of the Bill Menu
outputBill = Label(w1, font=('Arial', 18))
outputBill.grid(row=1, column=1, sticky=E)

# Button to call calculations
calcButton = Button(w1, text='Calculate Your Free Money', command=calFree, font=('Arial', 12))
calcButton.grid(row=2, column=0, pady=50, padx=10)

# Output the free money left over every month
outputFree = Label(w1, font=('Arial', 50))
outputFree.grid(row=3, column=0, padx= 15, pady=15, columnspan=4)

# Button to close program
exitButton = Button(w1, text="Exit", command=closeprog, font=('Arial', 12))
exitButton.grid(row=5, column=0, pady=5)

# Main Loop
w1.mainloop()