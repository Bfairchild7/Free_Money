# Import Tkinter
from tkinter import *
import tkinter as tk

# Setting up the first window
w1 = Tk()
w1.geometry("760x860")
w1.resizable(False, False)
w1.title("Free_Money")
bg1 = PhotoImage(file="projFiles/bg1.png")

# Setting the background for the first window
bgLab = Label(w1, image=bg1)
bgLab.place(x=0, y=0, relwidth=1, relheight=1)


# Setting up and def out second window for entering bills due
def open0():
    def saveb():
        file_name = entry.get()
        with open("projFiles/bills.txt", 'w') as file_object:
            file_object.write(file_name)
            file_object.close()

    entry_field_variable = tk.StringVar()
    w2 = Toplevel()
    w2.title("Enter Bills Due")
    w2.geometry("260x260")
    Label(w2, text="Enter Your Total Bills Due Each Month").pack(pady=20, padx=20)
    entry = tk.Entry(w2, textvariable=entry_field_variable)
    entry.pack()
    tk.Button(w2, text="Submit Value", command=saveb).pack(pady=10)
    tk.Button(w2, text="Close Menu", command=w2.destroy).pack(pady=10)


def open1():
    def savei():
        file_name = entry.get()
        with open("projFiles/income.txt", 'w') as file_objecti:
            file_objecti.write(file_name)
            file_objecti.close()

    entry_field_variable = tk.StringVar()
    w3 = Toplevel()
    w3.title("Enter Your Total Income")
    w3.geometry("260x260")
    Label(w3, text="Enter Your Total Income For The Month").pack(pady=20, padx=20)
    entry = tk.Entry(w3, textvariable=entry_field_variable)
    entry.pack()
    tk.Button(w3, text="Submit Value", command=savei).pack(pady=10)
    tk.Button(w3, text="Close Menu", command=w3.destroy).pack(pady=10)


label = Label(w1, text="Free_Money", fg="white", bg='black', font=('Times', "30", "italic"))
label.pack(anchor='w')

# Button to open second  and third windows
Button(w1, text="Enter Bills Due", height=2, width=16, command=open0).pack(padx=30, pady=6, anchor='e')
Button(w1, text="Enter Month Income", height=2, width=16, command=open1).pack(padx=30, pady=6, anchor='e')

# Main Loop
w1.mainloop()